var renderPoint = document.querySelector('.product-wrapper');
var oSubTotal = document.querySelector('.order-summary-sub-total');
var stdShip = document.querySelector('.order-summary-standard-shipping');
var oDiscount = document.querySelector('.order-summary-discount');
var grandTotal = document.querySelector('.order-summary-total');
var chkOut = document.querySelector('.order-summary-checkout');
var orderSummary = document.querySelector('.orderSummary');


var listedPincodes = [];
var totalAmount = [];
var listedDiscount;
orderSummaryShipping = {
  shippingPrice: 0,
  servingHere: false
};
fetch("../data.json", {
    mode: 'cors',
    headers: {
    'Access-Control-Allow-Origin':'*'
  }
})
.then(res => res.json())
.then(data => renderProducts(data))

function renderProducts(data) {
  let listedProducts = data.products;
  listedPincodes.push(data.pincode);
  listedDiscount = data.discount;
  for(let i = 0; i < listedProducts.length; i++) {
    let product = listedProducts[i];  
    renderPoint.innerHTML += `
      <div class="row mb-5" data-rowId="${product.id}">
        <div class="col-md-5">
            <div class="product-main">
              <div class="row">
                <div class="col-sm-4">
                  <div class="product-thum">
                      <img class="product-img" src="${product.imageUrl}" alt="${product.name}">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="product-name">${product.name}</div>
                  <div class="product-desc text-muted">${product.desc}</div>
                  <div class="gift-wrapper"></div>
                </div>
              </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="product-price product-price${product.id}">${product.price}</div>
        </div>
        <div class="col-md-2">
            <div class="product-quantity">
                <img class="decrese" id="minus" src="../icon/minus.png" onclick="removeOne(${product.id}, ${product.price});" />
                <input class="quantity quantity${product.id}" disabled />
                <img class="increase" id="minus" src="../icon/plus.png" onclick="addOne(${product.id}, ${product.price});" />
            </div>
        </div>
        <div class="col-md-2">
            <div class="product-subtotal">
                <span class="sub-total sub-total${product.id}">0</span>
                <span>$</span>
            </div>
        </div>
        <div class="col-md-1">
            <img class="delBtn" src="../icon/DELETE.png" onclick="deleteThis(this);" />
        </div>
    </div>
    `;
    var giftWrapper = document.querySelectorAll('.gift-wrapper');
    for(let j = 0; j < giftWrapper.length; j++) {
      if(product.gift !== undefined) {
        giftWrapper[i].innerHTML += `
            <div class="giftTag">Gift</div>
            <div class="gift-name">${product.gift.name}</div>
            <div class="gift-desc">${product.gift.desc}
                <span class="view-plan"><a href="${product.planLink}">view plans</span>
            </div>
        `;
      }
      break;
    }
  }
}

function addOne(productId, price) {
  let quan = document.querySelector('.quantity'+ productId);
  if(quan.value >= 0) {
    quan.value = Number(quan.value) + 1;
    updateSubtotal(productId, quan.value, price);
  }
}

function removeOne(productId, price) {
  let quan = document.querySelector('.quantity'+ productId);
  if(quan.value > 0) {
    quan.value = Number(quan.value) - 1;
    updateSubtotal(productId, quan.value, price);
  }
}

function deleteThis(e) {
  // need to write a function to get the closest parent node
  e.parentNode.parentNode.remove(e.parentNode.parentNode);
}

function updateSubtotal(productId, value, price) {
  if(value > -1) {
    let subTotal = document.querySelector('.sub-total'+ productId);
    let total = value*price;
    subTotal.innerText = total;
    updateOrderSummary(productId, value, price);
  }
}

function updateOrderSummary(productId, value, price) {
  let test = {
    "productId": productId,
    "value": value,
    "amount": price
  }
  if(totalAmount.length > 0) {
    for(let j = 0; j < totalAmount.length; j++) {  
      if(totalAmount[j]["productId"] === productId) {
        let index = j;
        if (index > -1) {
          totalAmount.splice(index, j)
          totalAmount[index] = test;
        }
      } else  {
        totalAmount.push(test);
        }
    }
   } else {
    totalAmount.push(test);
  }

  prepareFinalOrder();
}

function prepareFinalOrder() {
  let orderSummarySubTotal = getSum();
  let orderSummarydiscount = calculateTheDiscountOnTotal(orderSummarySubTotal, listedDiscount.discountPercentage);

  if(orderSummaryShipping.servingHere && orderSummarySubTotal > 0) {
    chkOut.removeAttribute('disabled');
    orderSummary.classList.remove('d-none');
  }
  orderSummaryShipping.shippingPrice == 0 ? stdShip.innerHTML = `Free` : stdShip.innerHTML = `${orderSummaryShipping.shippingPrice}`;
  
  let orderSummaryTotal = 0;

  oSubTotal.innerHTML = `${orderSummarySubTotal}$`;

  if(orderSummarySubTotal > listedDiscount.minTotal) {
    oDiscount.innerHTML = `${orderSummarydiscount}$`;
  }
  
  orderSummaryTotal = (orderSummarySubTotal - orderSummarydiscount + orderSummaryShipping.shippingPrice);
  grandTotal.innerHTML = `<h3>${orderSummaryTotal}.00$</h3>`  
}

function calculateTheDiscountOnTotal(total, discount) {
  let discountDollar = (total/100)*discount;
  return discountDollar;
}

function getSum() {
  let total = 0;
  for(let i = 0; i < totalAmount.length; i++) {
    total += totalAmount[i].amount * totalAmount[i].value; 
  }
  return total;
}

function checkAvalibility() {
  let shippingPrice = 0,
  servingHere = false;
  let enteredPincode = document.querySelector('#checkAvalibility'),
  freeDelivery = document.querySelector('.delivery-price'),
  deliveryMode = document.querySelector('.delivery-mode'),
  estimatedDays = document.querySelector('.estimated-days');
  if(enteredPincode.value.length == 6) {
    for(let i = 0; i < Object.keys(listedPincodes[0]).length; i++) {
      if(enteredPincode.value == Object.keys(listedPincodes[0])[i]) {
        let pincodeInfo = listedPincodes[0][Object.keys(listedPincodes[0])[i]];
          pincodeInfo.deliveryPrice == 0 ? freeDelivery.innerHTML =`<img src="../icon/check.png" />Free  delivery` : freeDelivery.innerHTML = pincodeInfo.deliveryPrice +"Rs. charable.";
          pincodeInfo.cashOnDelivery ? deliveryMode.innerHTML =`<img src="../icon/check.png" />Cash on delivery` : deliveryMode.innerHTML = "";
          estimatedDays.innerHTML =`<img src="../icon/check.png" />Estimated delivery time is ${pincodeInfo.estimatedDays.min} - ${pincodeInfo.estimatedDays.max} days.`;
          
          
          servingHere = true;
          if(pincodeInfo.deliveryPrice !== 0) {
            shippingPrice = pincodeInfo.deliveryPrice;
          }
      }
    }    
  }
  orderSummaryShipping = {
    shippingPrice,
    servingHere
  };
  prepareFinalOrder();
}